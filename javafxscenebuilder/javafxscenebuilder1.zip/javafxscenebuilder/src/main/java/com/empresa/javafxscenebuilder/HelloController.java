package com.empresa.javafxscenebuilder;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    private ComboBox<String> combo1; // Asegúrate de que el ComboBox tiene el tipo genérico String.

    @FXML
    public void initialize() {
        combo1.getItems().addAll("Ciudad 1", "Ciudad 2", "Ciudad 3", "Ciudad 4", "Ciudad 5");
        combo1.getSelectionModel().selectFirst(); // Selecciona la primera ciudad por defecto.
    }

    @FXML
    protected void onHelloButtonClick() {
        String ciudad = combo1.getSelectionModel().getSelectedItem();
        welcomeText.setText("Bienvenido a " + ciudad + "!");
        System.out.println(ciudad); // Esta línea puede ser eliminada si no necesitas la salida en consola.
    }
}
